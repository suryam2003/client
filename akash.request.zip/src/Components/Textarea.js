import React from "react";
import "./Textarea.css";

function Textarea({ lable, placeholder }) {
  return (
    <div>
      <lable>{lable}</lable>
      <textarea className="textarea" placeholder={placeholder} />
    </div>
  );
}

export default Textarea;
