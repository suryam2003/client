import React from "react";
import "./Input.css";

function Input({ placeholder, label }) {
  return (
    <div>
      <label>{label}</label>
      <input className="inputfield" type="text" placeholder={placeholder} />
    </div>
  );
}

export default Input;
