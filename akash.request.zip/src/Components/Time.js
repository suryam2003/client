import React from "react";

function Time({ label , placeholder }) {
  return (
    <div>
     <label>{label}</label>
      <input className="inputfield " type="time" placeholder={placeholder}  />
    </div>
  );
}

export default Time;
