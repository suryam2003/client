import React from "react";
import "./Button.css";

function Button({Title}){
  return(
    <button className="btn">{Title}</button>
  )
}

export default Button