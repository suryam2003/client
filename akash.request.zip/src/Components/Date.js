import React from "react";
import "./Date.css";

function Date({ label, placeholder }) {
  return (
    <div>
      <label>{label}</label>
      <input className="date" type="date" placeholder={placeholder} />
    </div>
  );
}
 
export default Date