import React from 'react';
import './App.css';
import Form from './Form' 


function App() {
  return (
     <div className="mainontainer">
       <Form/>
     </div>
  );
}

export default App;
