import React from "react";
import Button from "./Components/Button";
import Input from "./Components/Input";
import "./Form.css";
import Time from "./Components/Time";
import Date from "./Components/Date";
// import Short from "./Components/Short";
import Textarea from "./Components/Textarea";

function Form() {
  return (
    <div className="formContainer">
      <div className="heading">Interview Request</div>
      <hr />
      <div className="form">
        <div className="left">
          <Input placeholder="Interviewer" label="Name" />
          <Input placeholder="name@gmail.com" label="Email" />

          <Date label="Date" />
          <Textarea placeholder="Sort Message" lable="Sort Message" />
        </div>
        <div className="right">
          <Input placeholder="http.com" label="Link Of Website" />
          <Input placeholder="Wipro" label="Company" />
          <Time label="Time" />
          <Input placeholder="Invited Student" />
          <Button Title="Send" />
        </div>
      </div>
    </div>
  );
}

export default Form;
